## [1.1.0]

##### Update react class components to functional components

## [1.0.0]

##### Initial version of the project
