const hasToken = (token) => {
  if (token) {
    return true
  }
}

export default hasToken;
